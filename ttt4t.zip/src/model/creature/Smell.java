package model.creature;

/**
 * Smell of otyughs in the dungeon.
 *
 */
public enum Smell {
  STRONG,
  NORMAL,
  NONE;
}
