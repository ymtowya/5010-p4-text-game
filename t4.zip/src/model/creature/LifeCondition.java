package model.creature;

/**
 * Life condition of the Otyugh.
 *
 */
public enum LifeCondition {
  HEALTHY,
  HURT,
  DEAD;
}
